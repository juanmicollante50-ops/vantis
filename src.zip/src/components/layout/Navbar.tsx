import { Link } from "react-router-dom";

const links = [
  { name: "Inicio", href: "/" },
  { name: "Software", href: "/software" },
  { name: "IA", href: "/ia" },
  { name: "Desarrollo Web", href: "/web" },
  { name: "Nosotros", href: "/nosotros" },
  { name: "Contacto", href: "/contacto" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur border-b border-slate-200">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">

        <Link
          to="/"
          className="text-2xl font-extrabold tracking-tight text-slate-900"
        >
          VANTIS
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <Link
              key={link.name}
              to={link.href}
              className="text-sm font-medium text-slate-600 transition hover:text-slate-900"
            >
              {link.name}
            </Link>
          ))}
        </nav>

        <button className="rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">
          Cotizar
        </button>

      </div>
    </header>
  );
}