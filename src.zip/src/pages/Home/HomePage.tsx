export default function HomePage() {
  return (
    <section className="min-h-screen flex items-center justify-center bg-white">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-slate-900">
          VANTIS
        </h1>

        <p className="mt-6 text-xl text-slate-600">
          Software • IA • Automatización
        </p>

        <button className="mt-10 rounded-xl bg-blue-600 px-8 py-4 text-white transition hover:bg-blue-700">
          Cotizar proyecto
        </button>
      </div>
    </section>
  );
}